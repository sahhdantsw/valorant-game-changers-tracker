@echo off
setlocal
cd /d "%~dp0"
title Instalar - VALORANT Game Changers

set "VENV_PY=%~dp0.venv\Scripts\python.exe"
set "EXE=%~dp0dist\ValorantGameChangers.exe"
set "INSTALL_DIR=%LOCALAPPDATA%\Programs\ValorantGameChangers"
set "DATA_DIR=%APPDATA%\Valorant Game Changers"

if not exist "%~dp0.venv\Scripts\python.exe" (
    where uv >nul 2>&1
    if errorlevel 1 (
        echo O comando uv nao foi encontrado. Instala o uv e tenta novamente.
        pause
        exit /b 1
    )
    echo A preparar o ambiente Python do projeto...
    uv sync --project "%~dp0"
    if errorlevel 1 goto :failed
)

if not exist "%VENV_PY%" (
    echo Nao foi possivel preparar o ambiente Python do projeto.
    goto :failed
)

if not exist "%EXE%" (
    where uv >nul 2>&1
    if errorlevel 1 (
        echo O comando uv nao foi encontrado. Instala o uv e tenta novamente.
        pause
        exit /b 1
    )
    echo A preparar as ferramentas de empacotamento...
    uv pip install --python "%VENV_PY%" "flet-cli==1.0.5" pyinstaller
    if errorlevel 1 goto :failed
    echo A criar o executavel. Esta etapa pode demorar alguns minutos...
    "%~dp0.venv\Scripts\flet.exe" pack "%~dp0app.py" --name ValorantGameChangers --icon "%~dp0assets\valorant_gc.ico" --product-name "VALORANT Game Changers" --file-description "VALORANT Game Changers match notifier" --product-version 1.0.0.0 --file-version 1.0.0.0 --hidden-import tzdata --yes
    if errorlevel 1 goto :failed
)

if not exist "%EXE%" (
    echo O executavel nao foi criado.
    goto :failed
)

if not exist "%INSTALL_DIR%" mkdir "%INSTALL_DIR%"
if errorlevel 1 goto :failed
if not exist "%DATA_DIR%" mkdir "%DATA_DIR%"
if errorlevel 1 goto :failed

copy /Y "%EXE%" "%INSTALL_DIR%\ValorantGameChangers.exe" >nul
if errorlevel 1 goto :failed
if not exist "%DATA_DIR%\config.json" if exist "%~dp0config.json" copy /Y "%~dp0config.json" "%DATA_DIR%\config.json" >nul
if not exist "%DATA_DIR%\notified.json" if exist "%~dp0notified.json" copy /Y "%~dp0notified.json" "%DATA_DIR%\notified.json" >nul
if not exist "%DATA_DIR%\.env" if exist "%~dp0.env" copy /Y "%~dp0.env" "%DATA_DIR%\.env" >nul
if not exist "%DATA_DIR%\.env" if exist "%~dp0.env.example" copy /Y "%~dp0.env.example" "%DATA_DIR%\.env" >nul

if not exist "%INSTALL_DIR%\assets" mkdir "%INSTALL_DIR%\assets"
copy /Y "%~dp0assets\valorant_gc.ico" "%INSTALL_DIR%\assets\valorant_gc.ico" >nul
if errorlevel 1 goto :failed

echo A configurar o inicio com o Windows...
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0instalar_arranque.ps1" -AppPath "%INSTALL_DIR%\ValorantGameChangers.exe"
if errorlevel 1 goto :failed

echo A iniciar a aplicacao minimizada. Clica no icone da barra de tarefas para abrir.
start "" "%INSTALL_DIR%\ValorantGameChangers.exe" --background
echo.
echo Instalacao concluida. Os dados e o ficheiro .env ficam em:
echo %DATA_DIR%
pause
exit /b 0

:failed
echo.
echo A instalacao falhou. Le a mensagem acima e tenta novamente.
pause
exit /b 1
