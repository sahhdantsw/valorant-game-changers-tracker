param(
    [Parameter(Mandatory = $true)]
    [string]$AppPath
)

$runKey = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Run"
$command = '"' + $AppPath + '" --background'
Set-ItemProperty -Path $runKey -Name "ValorantGameChangersWidget" -Value $command

$startMenu = [Environment]::GetFolderPath("StartMenu")
$shortcutPath = Join-Path $startMenu "Programs\VALORANT Game Changers.lnk"
$shell = New-Object -ComObject WScript.Shell
$shortcut = $shell.CreateShortcut($shortcutPath)
$shortcut.TargetPath = $AppPath
$shortcut.WorkingDirectory = Split-Path -Parent $AppPath
$shortcut.IconLocation = (Join-Path (Split-Path -Parent $AppPath) "assets\valorant_gc.ico")
$shortcut.Save()
