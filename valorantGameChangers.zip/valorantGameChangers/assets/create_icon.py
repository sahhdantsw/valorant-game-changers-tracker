from pathlib import Path
import struct


SIZE = 256
ICON = Path(__file__).with_name("valorant_gc.ico")


def inside_polygon(x, y, points):
    hit = False
    j = len(points) - 1
    for i, (xi, yi) in enumerate(points):
        xj, yj = points[j]
        if (yi > y) != (yj > y):
            crossing = (xj - xi) * (y - yi) / (yj - yi) + xi
            if x < crossing:
                hit = not hit
        j = i
    return hit


def rounded_square(x, y, radius=42):
    cx = min(max(x, radius), SIZE - radius - 1)
    cy = min(max(y, radius), SIZE - radius - 1)
    return (x - cx) ** 2 + (y - cy) ** 2 <= radius**2


def main():
    red = (255, 70, 85, 255)
    white = (255, 255, 255, 255)
    left_stroke = [(48, 52), (94, 52), (137, 179), (117, 222)]
    right_stroke = [(130, 179), (162, 52), (208, 52), (151, 222)]
    pixels = []
    mask_rows = []

    for y in range(SIZE):
        row = []
        mask = bytearray((SIZE + 7) // 8)
        for x in range(SIZE):
            if not rounded_square(x, y):
                color = (0, 0, 0, 0)
                mask[x // 8] |= 1 << (7 - x % 8)
            elif inside_polygon(x + 0.5, y + 0.5, left_stroke):
                color = red
            elif inside_polygon(x + 0.5, y + 0.5, right_stroke):
                color = white
            else:
                color = (15, 17, 24, 255)
            row.append(color)
        pixels.append(row)
        mask_rows.append(bytes(mask))

    image = bytearray()
    for row in reversed(pixels):
        for r, g, b, a in row:
            image.extend((b, g, r, a))

    mask_data = b"".join(reversed(mask_rows))
    header = struct.pack("<IIIHHIIIIII", 40, SIZE, SIZE * 2, 1, 32, 0,
                         len(image), 0, 0, 0, 0)
    dib = header + image + mask_data
    ico_header = struct.pack("<HHH", 0, 1, 1)
    directory = struct.pack("<BBBBHHII", 0, 0, 0, 0, 1, 32, len(dib), 22)
    ICON.write_bytes(ico_header + directory + dib)
    print(f"Ícone criado: {ICON}")


if __name__ == "__main__":
    main()
