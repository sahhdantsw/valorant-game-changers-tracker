import asyncio
import json
import os
import smtplib
import ssl
import sys
import threading
from datetime import datetime, timezone
from email.message import EmailMessage
from pathlib import Path
from urllib.parse import urlencode
from urllib.request import Request, urlopen
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

import flet as ft

# A lista é o catálogo informado pela utilizadora; a API serve apenas horários e logótipos.
API = "https://vctgemini.vercel.app/v2"
APP_ROOT = Path(sys.executable).resolve().parent if getattr(sys, "frozen", False) else Path(__file__).resolve().parent
DATA_ROOT = (
    Path(os.getenv("APPDATA", Path.home() / "AppData" / "Roaming")) / "Valorant Game Changers"
    if getattr(sys, "frozen", False) else APP_ROOT
)
DATA_ROOT.mkdir(parents=True, exist_ok=True)
CONFIG_FILE = DATA_ROOT / "config.json"
SENT_FILE = DATA_ROOT / "notified.json"
ENV_FILE = DATA_ROOT / ".env"
ICON_FILE = APP_ROOT / "assets" / "valorant_gc.ico"

BLACK = "#000000"
WHITE = "#FFFFFF"
INK = "#151515"
GRAY = "#6B6B6B"
LINE = "#D9D9D9"
SOFT = "#F5F5F5"
RED = "#E53935"
GREEN = "#27834A"

TIMEZONES = {
    "Portugal": "Europe/Lisbon",
    "Brasil — Brasília": "America/Sao_Paulo",
    "Brasil — Manaus": "America/Manaus",
    "Brasil — Acre": "America/Rio_Branco",
    "Espanha": "Europe/Madrid",
    "Reino Unido": "Europe/London",
    "França": "Europe/Paris",
    "Alemanha": "Europe/Berlin",
    "Estados Unidos — Nova York": "America/New_York",
    "Japão": "Asia/Tokyo",
}

BRAZIL_STAGES = [
    "Team Liquid Brazil", "MIBR GC", "Evil Geniuses GC", "Ushiras",
    "Arashi GC", "PÃO COM RATO", "7VEN STARS", "Evils of Delusion",
    "Forged To Shine GC", "GATO PENSANTE?",
]
BRAZIL_QUALIFIERS = [
    "Gênias do Bem", "Barões da Academia", "OUROBOROS",
    "Aura Farming", "Beta Division GC",
]
WORLD_TEAMS = [
    "Team Liquid Brazil", "MIBR GC", "Shopify Rebellion Gold", "KRÜ Blaze",
    "G2 Gozen", "Gentle Mates GC", "SK Nebula", "Gen.G GC",
    "FENNEL Female", "Nova Esports GC",
]
BRAZIL_TEAMS = BRAZIL_STAGES + BRAZIL_QUALIFIERS
ALL_TEAMS = list(dict.fromkeys(BRAZIL_TEAMS + WORLD_TEAMS))


def load_env():
    try:
        rows = ENV_FILE.read_text(encoding="utf-8-sig").splitlines()
    except OSError:
        return
    for row in rows:
        row = row.strip()
        if not row or row.startswith("#") or "=" not in row:
            continue
        key, value = row.split("=", 1)
        value = value.strip()
        if len(value) >= 2 and value[0] == value[-1] and value[0] in "\"'":
            value = value[1:-1]
        os.environ.setdefault(key.strip(), value)


def read_json(path, fallback):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return fallback


def write_json(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def api_get(path, params=None):
    url = API + path + (("?" + urlencode(params)) if params else "")
    request = Request(url, headers={"User-Agent": "ValorantCalendar/1.0"})
    with urlopen(request, timeout=12) as response:
        return json.loads(response.read().decode("utf-8"))


def get_segments(payload):
    data = payload.get("data", {})
    result = data.get("segments", []) if isinstance(data, dict) else []
    return result if isinstance(result, list) else []


def match_start(match):
    raw = match.get("unix_timestamp")
    if not raw:
        return None
    try:
        value = datetime.fromisoformat(str(raw).replace("Z", "+00:00"))
        return value.replace(tzinfo=timezone.utc) if value.tzinfo is None else value
    except ValueError:
        return None


def match_text(match):
    return (str(match.get("match_event", "")) + " " + str(match.get("match_series", ""))).casefold()


def is_game_changers(match):
    text = match_text(match)
    return "game changers" in text or "gamechangers" in text


def send_email(subject, body, recipient):
    host = os.getenv("SMTP_HOST", "").strip()
    port = int(os.getenv("SMTP_PORT", "587").strip())
    username = os.getenv("SMTP_USER", "").strip()
    password = os.getenv("SMTP_PASSWORD", os.getenv("SMTP_PASS", "")).strip()
    sender = os.getenv("EMAIL_FROM", os.getenv("SMTP_FROM", username)).strip()
    use_ssl = os.getenv("SMTP_USE_SSL", "false").strip().casefold() in ("1", "true", "yes", "sim")
    if not all((host, username, password, sender, recipient)):
        raise RuntimeError("Preenche os dados SMTP no ficheiro .env.")
    message = EmailMessage()
    message["Subject"] = subject
    message["From"] = sender
    message["To"] = recipient
    message.set_content(body)
    context = ssl.create_default_context()
    if use_ssl:
        with smtplib.SMTP_SSL(host, port, timeout=15, context=context) as server:
            server.login(username, password)
            server.send_message(message)
    else:
        with smtplib.SMTP(host, port, timeout=15) as server:
            server.ehlo()
            server.starttls(context=context)
            server.ehlo()
            server.login(username, password)
            server.send_message(message)


load_env()


async def main(page: ft.Page):
    saved = read_json(CONFIG_FILE, {})
    saved_screen = saved.get("screen", "competition")
    if saved_screen not in {"competition", "teams", "schedule", "email"}:
        saved_screen = "competition"
    saved_scope = saved.get("scope")
    if saved_scope not in {"world", "brazil", None}:
        saved_scope = None
    if saved_screen in {"teams", "schedule", "email"} and saved_scope is None:
        saved_screen = "competition"
    state = {
        "screen": saved_screen,
        "scope": saved_scope,
        "country": saved.get("country", "Portugal"),
        "favorites": set(saved.get("favorites", [])),
        "matches": [],
        "logos": {},
        "loading": False,
        "error": "",
        "email_enabled": saved.get("notifications", False),
        "recipient_email": saved.get("recipient_email", ""),
        "email_draft": saved.get("email_draft", saved.get("recipient_email", "")),
        "start_with_windows": saved.get("start_with_windows", False) or "--background" in sys.argv,
        "minutes_before": int(saved.get("minutes_before", 15)),
        "sent": set(read_json(SENT_FILE, [])),
        "pending": set(),
        "timezone_fallback": False,
    }

    page.title = "VALORANT · Game Changers"
    page.theme_mode = ft.ThemeMode.LIGHT
    page.bgcolor = WHITE
    page.padding = 0
    page.window.width = 1180
    page.window.height = 820
    page.window.min_width = 860
    page.window.min_height = 640
    page.window.always_on_top = True
    if ICON_FILE.exists():
        page.window.icon = str(ICON_FILE)
    page.window.prevent_close = True
    page.window.minimized = "--background" in sys.argv

    def handle_window_event(event):
        if event.type == ft.WindowEventType.CLOSE:
            # O X mantém a verificação ativa; a janela fica minimizada na barra de tarefas.
            page.window.minimized = True
            page.update()

    page.window.on_event = handle_window_event

    status = ft.Text("Escolhe uma competição para começar.", size=12, color=GRAY)
    body = ft.Container(expand=True)

    def save_config():
        write_json(CONFIG_FILE, {
            "favorites": sorted(state["favorites"], key=str.casefold),
            "screen": state["screen"],
            "scope": state["scope"],
            "country": state["country"],
            "notifications": state["email_enabled"],
            "recipient_email": state["recipient_email"],
            "email_draft": state["email_draft"],
            "start_with_windows": state["start_with_windows"],
            "minutes_before": state["minutes_before"],
        })

    if "--background" in sys.argv:
        save_config()

    def scope_teams():
        if state["scope"] == "world":
            return WORLD_TEAMS
        return BRAZIL_TEAMS

    def badge(text):
        return ft.Container(
            content=ft.Text(text, size=11, weight=ft.FontWeight.BOLD, color=INK),
            bgcolor=SOFT,
            padding=ft.Padding(left=10, top=6, right=10, bottom=6),
            border_radius=20,
        )

    def primary_button(text, on_click, icon=None):
        return ft.Button(
            text,
            icon=icon,
            height=44,
            bgcolor=BLACK,
            color=WHITE,
            on_click=on_click,
            style=ft.ButtonStyle(shape=ft.RoundedRectangleBorder(radius=6)),
        )

    def outline_button(text, on_click, icon=None):
        return ft.OutlinedButton(
            text,
            icon=icon,
            height=42,
            style=ft.ButtonStyle(
                color=BLACK,
                side=ft.BorderSide(1, LINE),
                shape=ft.RoundedRectangleBorder(radius=6),
            ),
            on_click=on_click,
        )

    def avatar(team, size=66):
        logo = state["logos"].get(team)
        initials = "".join(part[0] for part in team.replace("?", "").split()[:2]).upper()
        picture = (
            ft.Image(src=logo, width=size - 14, height=size - 14, fit=ft.BoxFit.CONTAIN,
                     error_content=ft.Text(initials, size=15, weight=ft.FontWeight.BOLD, color=INK))
            if logo else ft.Text(initials, size=15, weight=ft.FontWeight.BOLD, color=INK)
        )
        return ft.Container(
            content=picture, width=size, height=size, bgcolor=SOFT,
            border_radius=size / 2, alignment=ft.Alignment.CENTER,
        )

    def card(content, *, padding=18, on_click=None, selected=False):
        return ft.Container(
            content=content,
            padding=padding,
            bgcolor="#F7F7F7" if selected else WHITE,
            border=ft.Border.all(2 if selected else 1, BLACK if selected else LINE),
            border_radius=8,
            on_click=on_click,
        )

    def header():
        country = ft.Dropdown(
            label="Fuso horário",
            value=state["country"],
            width=220,
            text_size=13,
            color=WHITE,
            label_style=ft.TextStyle(color="#CACACA", size=11),
            border=ft.Border.all(1, "#555555"),
            border_radius=6,
            content_padding=ft.Padding(left=12, top=5, right=10, bottom=5),
            options=[ft.DropdownOption(key=name, text=name) for name in TIMEZONES],
            on_select=change_country,
        )
        return ft.Container(
            content=ft.Row(
                controls=[
                    ft.Row(
                        controls=[
                            ft.Container(
                                content=ft.Text("V", size=20, weight=ft.FontWeight.BOLD, color=BLACK),
                                width=38, height=38, bgcolor=WHITE,
                                alignment=ft.Alignment.CENTER, border_radius=6,
                            ),
                            ft.Column(
                                controls=[
                                    ft.Text("VALORANT", size=15, weight=ft.FontWeight.BOLD, color=WHITE),
                                    ft.Text("GAME CHANGERS", size=10, color="#D0D0D0"),
                                ], spacing=0,
                            ),
                        ], spacing=12,
                    ),
                    ft.Container(expand=True),
                    country,
                ],
                vertical_alignment=ft.CrossAxisAlignment.CENTER,
            ),
            bgcolor=BLACK,
            padding=ft.Padding(left=28, top=14, right=28, bottom=14),
        )

    def progress():
        labels = [("01", "COMPETIÇÃO"), ("02", "EQUIPAS"), ("03", "HORÁRIOS")]
        current = {"competition": 0, "teams": 1, "schedule": 2, "email": 2}[state["screen"]]
        controls = []
        for i, (number, title) in enumerate(labels):
            controls.append(ft.Row([
                ft.Container(
                    content=ft.Text(number, size=11, weight=ft.FontWeight.BOLD,
                                    color=WHITE if i <= current else GRAY),
                    width=28, height=28,
                    bgcolor=BLACK if i <= current else "#EDEDED",
                    alignment=ft.Alignment.CENTER, border_radius=20,
                ),
                ft.Text(title, size=10, weight=ft.FontWeight.BOLD,
                        color=BLACK if i == current else GRAY),
            ], spacing=8))
            if i < 2:
                controls.append(ft.Container(width=34, height=1, bgcolor=LINE))
        return ft.Row(controls, alignment=ft.MainAxisAlignment.CENTER, spacing=12)

    def main_column(controls):
        return ft.Container(
            content=ft.Column(controls, spacing=18, scroll=ft.ScrollMode.AUTO),
            width=1050,
            padding=ft.Padding(left=24, top=28, right=24, bottom=28),
        )

    def competition_card(title, subtitle, icon, mode):
        return ft.Container(
            col={ft.ResponsiveRowBreakpoint.XS: 12, ft.ResponsiveRowBreakpoint.MD: 6},
            content=card(
                ft.Column(
                    controls=[
                        ft.Icon(icon, size=28, color=BLACK),
                        ft.Container(height=4),
                        ft.Text(title, size=18, weight=ft.FontWeight.BOLD, color=BLACK),
                        ft.Text(subtitle, size=13, color=GRAY),
                        ft.Container(height=8),
                        primary_button("Escolher equipas", lambda e, m=mode: choose_scope(m),
                                       icon=ft.Icons.ARROW_FORWARD),
                    ], spacing=8,
                ),
                padding=24,
            ),
        )

    def competition_screen():
        return ft.Row(
            controls=[
                ft.Container(
                    content=ft.Column(
                        controls=[
                            badge("ACOMPANHAMENTO DE ESPORTS"),
                            ft.Text("O que queres acompanhar?", size=28,
                                    weight=ft.FontWeight.BOLD, color=BLACK),
                            ft.Text("Escolhe a competição. Depois selecionas as equipas e consultamos os horários.",
                                    size=14, color=GRAY),
                            ft.ResponsiveRow(
                                controls=[
                                    competition_card(
                                        "Mundial", "Game Changers Championship", ft.Icons.PUBLIC, "world"),
                                    competition_card(
                                        "Jogos no Brasil", "Circuito brasileiro Game Changers", ft.Icons.FLAG_OUTLINED, "brazil"),
                                ],
                                spacing=16, run_spacing=16,
                            ),
                        ], spacing=14,
                    ),
                    width=1050,
                    padding=ft.Padding(left=24, top=40, right=24, bottom=36),
                )
            ],
            alignment=ft.MainAxisAlignment.CENTER,
            vertical_alignment=ft.CrossAxisAlignment.CENTER,
            expand=True,
        )

    def team_tile(team):
        selected = team in state["favorites"]
        icon = ft.Icon(
            ft.Icons.CHECK_CIRCLE if selected else ft.Icons.ADD_CIRCLE_OUTLINE,
            color=BLACK if selected else GRAY,
            size=22,
        )
        return ft.Container(
            col={ft.ResponsiveRowBreakpoint.XS: 12,
                 ft.ResponsiveRowBreakpoint.MD: 6,
                 ft.ResponsiveRowBreakpoint.LG: 4},
            content=card(
                ft.Row(
                    controls=[
                        avatar(team, 60),
                        ft.Column(
                            controls=[
                                ft.Text(team, size=14, weight=ft.FontWeight.BOLD, color=BLACK),
                                ft.Text("Receber aviso por email" if selected else "Toca para acompanhar",
                                        size=11, color=GRAY),
                            ], spacing=4, expand=True,
                        ),
                        icon,
                    ], spacing=14,
                    vertical_alignment=ft.CrossAxisAlignment.CENTER,
                ),
                padding=14,
                on_click=lambda e, t=team: toggle_team(t),
                selected=selected,
            ),
        )

    def team_section(title, names):
        return ft.Column(
            controls=[
                ft.Row([ft.Text(title, size=16, weight=ft.FontWeight.BOLD, color=BLACK),
                        badge(f"{len(names)} equipas")], spacing=12),
                ft.ResponsiveRow(
                    controls=[team_tile(team) for team in names],
                    spacing=12, run_spacing=12,
                ),
            ], spacing=12,
        )

    def teams_screen():
        if state["scope"] == "world":
            sections = [team_section("Mundial Game Changers 2026", WORLD_TEAMS)]
            title = "Equipas do Mundial"
            subtitle = "Seleciona uma ou mais equipas para receber os respetivos horários por email."
        else:
            sections = [
                team_section("Etapas principais", BRAZIL_STAGES),
                team_section("Acesso e qualificatórias", BRAZIL_QUALIFIERS),
            ]
            title = "Equipas do circuito brasileiro"
            subtitle = "Seleciona as equipas brasileiras que queres acompanhar."
        selected_count = len(state["favorites"].intersection(scope_teams()))
        controls = [
            ft.Row([
                outline_button("Voltar", lambda e: go_to("competition"), icon=ft.Icons.ARROW_BACK),
                ft.Container(expand=True),
                badge(f"{selected_count} selecionadas"),
            ]),
            ft.Text(title, size=26, weight=ft.FontWeight.BOLD, color=BLACK),
            ft.Text(subtitle, size=13, color=GRAY),
            ft.Row([
                outline_button("Selecionar todas", lambda e: select_all(True)),
                outline_button("Limpar", lambda e: select_all(False)),
            ], spacing=8),
            *sections,
            ft.Row([
                ft.Text(f"{selected_count} equipa(s) selecionada(s)", size=12, color=GRAY),
                ft.Container(expand=True),
                primary_button("Ver horários", lambda e: go_to("schedule"), icon=ft.Icons.ARROW_FORWARD),
            ]),
        ]
        return ft.Row([main_column(controls)], alignment=ft.MainAxisAlignment.CENTER,
                      expand=True, vertical_alignment=ft.CrossAxisAlignment.START)

    def match_scope(match):
        if not is_game_changers(match):
            return None
        event = match_text(match)
        first = str(match.get("team1", ""))
        second = str(match.get("team2", ""))
        participants = (first + " " + second).casefold()
        championship = "championship" in event or "mundial" in event
        if championship and any(team.casefold() in participants for team in WORLD_TEAMS):
            return "world"
        if not championship and any(team.casefold() in participants for team in BRAZIL_TEAMS):
            return "brazil"
        return None

    def selected_match_team(match, scope):
        allowed = WORLD_TEAMS if scope == "world" else BRAZIL_TEAMS
        participants = (str(match.get("team1", "")) + " " + str(match.get("team2", ""))).casefold()
        return next((team for team in state["favorites"]
                     if team in allowed and team.casefold() in participants), None)

    def scheduled_rows(scope):
        try:
            tz = ZoneInfo(TIMEZONES.get(state["country"], "Europe/Lisbon"))
            state["timezone_fallback"] = False
        except ZoneInfoNotFoundError:
            # Windows pode não incluir a base IANA. Usa o fuso local até tzdata ser instalado.
            tz = datetime.now().astimezone().tzinfo or timezone.utc
            state["timezone_fallback"] = True
        rows = []
        for match in state["matches"]:
            if match_scope(match) != scope:
                continue
            followed = selected_match_team(match, scope)
            if not followed:
                continue
            first = str(match.get("team1", "Equipa 1"))
            second = str(match.get("team2", "Equipa 2"))
            opponent = second if followed.casefold() in first.casefold() else first
            start = match_start(match)
            local_start = start.astimezone(tz) if start else None
            rows.append((local_start, followed, opponent, match.get("match_event", "Game Changers"), match))
        rows.sort(key=lambda row: row[0] or datetime.max.replace(tzinfo=tz))
        return rows

    def game_card(row):
        start, followed, opponent, event, match = row
        date_text = start.strftime("%d %b").upper() if start else "DATA\nA CONFIRMAR"
        time_text = start.strftime("%H:%M") if start else "—:—"
        return card(
            ft.Row(
                controls=[
                    ft.Container(
                        content=ft.Column([
                            ft.Text(date_text, size=11, weight=ft.FontWeight.BOLD, color=GRAY,
                                    text_align=ft.TextAlign.CENTER),
                            ft.Text(time_text, size=18, weight=ft.FontWeight.BOLD, color=BLACK,
                                    text_align=ft.TextAlign.CENTER),
                        ], horizontal_alignment=ft.CrossAxisAlignment.CENTER, spacing=3),
                        width=88, padding=10, bgcolor=SOFT, border_radius=6,
                    ),
                    ft.Column([
                        ft.Row([
                            ft.Text(followed, size=14, weight=ft.FontWeight.BOLD, color=BLACK),
                            ft.Text("vs", size=12, color=GRAY),
                            ft.Text(opponent, size=14, weight=ft.FontWeight.BOLD, color=BLACK),
                        ], wrap=True, spacing=8),
                        ft.Text(str(event), size=12, color=GRAY),
                    ], spacing=6, expand=True),
                    ft.Icon(ft.Icons.CHEVRON_RIGHT, color=GRAY),
                ], spacing=16,
                vertical_alignment=ft.CrossAxisAlignment.CENTER,
            ),
            padding=14,
        )

    def email_setup_screen():
        address = ft.TextField(
            label="O teu endereço de email",
            hint_text="nome@exemplo.com",
            value=state["email_draft"],
            keyboard_type=ft.KeyboardType.EMAIL,
            autofocus=True,
            width=460,
            border_radius=8,
            on_change=lambda e: save_email_draft(e.control.value),
        )
        feedback = ft.Text("", size=12, color=RED)

        def confirm(e):
            email = (address.value or "").strip()
            if "@" not in email or "." not in email.rsplit("@", 1)[-1] or any(ch.isspace() for ch in email):
                feedback.value = "Escreve um endereço de email válido."
                page.update()
                return
            state["recipient_email"] = email
            state["email_draft"] = email
            state["email_enabled"] = True
            save_config()
            status.value = "Avisos por email ativados."
            go_to("schedule")

        return ft.Row([main_column([
            outline_button("Voltar aos horários", lambda e: go_to("schedule"), icon=ft.Icons.ARROW_BACK),
            badge("AVISOS DE JOGOS"),
            ft.Text("Para que email enviamos os avisos?", size=26, weight=ft.FontWeight.BOLD, color=BLACK),
            ft.Text("O endereço fica guardado apenas neste computador. Os dados SMTP de envio continuam no ficheiro .env.",
                    size=13, color=GRAY),
            address,
            feedback,
            primary_button("Confirmar e ativar avisos", confirm, icon=ft.Icons.MAIL_OUTLINE),
        ])], alignment=ft.MainAxisAlignment.CENTER, expand=True,
            vertical_alignment=ft.CrossAxisAlignment.START)

    def schedule_screen():
        scope = state["scope"] or "world"
        rows = scheduled_rows(scope)
        title = "Mundial Game Changers 2026" if scope == "world" else "Jogos no Brasil"
        if state["email_enabled"] and state["recipient_email"]:
            email_control = ft.Row([
                ft.Icon(ft.Icons.MAIL_OUTLINE, color=GREEN, size=20),
                ft.Text(f"Avisos ativos para {state['recipient_email']}", size=13, color=INK),
                outline_button("Alterar email", lambda e: go_to("email")),
                outline_button("Desativar", lambda e: disable_email()),
            ], spacing=10, wrap=True, vertical_alignment=ft.CrossAxisAlignment.CENTER)
        else:
            email_control = primary_button(
                "Quero receber avisos por email", lambda e: go_to("email"), icon=ft.Icons.MAIL_OUTLINE
            )
        if not state["favorites"].intersection(scope_teams()):
            empty = card(ft.Column([
                ft.Icon(ft.Icons.NOTIFICATIONS_NONE, size=30, color=GRAY),
                ft.Text("Ainda não escolheste equipas", size=16, weight=ft.FontWeight.BOLD, color=BLACK),
                ft.Text("Volta à seleção e marca as equipas que queres acompanhar.", size=12, color=GRAY),
            ], horizontal_alignment=ft.CrossAxisAlignment.CENTER, spacing=8), padding=28)
        elif state["loading"]:
            empty = ft.Row([ft.ProgressRing(width=20, height=20),
                            ft.Text("A procurar horários…", color=GRAY)], spacing=12)
        elif not rows:
            empty = card(ft.Column([
                ft.Icon(ft.Icons.EVENT_BUSY, size=30, color=GRAY),
                ft.Text("Sem horários publicados", size=16, weight=ft.FontWeight.BOLD, color=BLACK),
                ft.Text("Ainda não há próximos jogos destas equipas na fonte de dados.", size=12, color=GRAY),
                primary_button("Atualizar horários", lambda e: refresh_data(), icon=ft.Icons.REFRESH),
            ], horizontal_alignment=ft.CrossAxisAlignment.CENTER, spacing=10), padding=28)
        else:
            empty = ft.Column([game_card(row) for row in rows], spacing=10)
        controls = [
            ft.Row([
                outline_button("Voltar às equipas", lambda e: go_to("teams"), icon=ft.Icons.ARROW_BACK),
                ft.Container(expand=True),
                badge(f"{len(rows)} jogos"),
                outline_button("Sair completamente", exit_app, icon=ft.Icons.CLOSE),
            ]),
            ft.Text(title, size=26, weight=ft.FontWeight.BOLD, color=BLACK),
            ft.Text("Horários no teu fuso local. O aviso por email usa a antecedência definida abaixo.",
                    size=13, color=GRAY),
            ft.Container(
                content=ft.Column([
                    email_control,
                    ft.Row([
                        ft.Text("Avisar", size=12, color=GRAY),
                        ft.Dropdown(
                            value=str(state["minutes_before"]),
                            width=110,
                            content_padding=ft.Padding(left=8, top=2, right=8, bottom=2),
                            options=[ft.DropdownOption(key=str(n), text=f"{n} min") for n in (5, 10, 15, 30, 60)],
                            on_select=change_lead,
                        ),
                        ft.Text("antes do jogo", size=12, color=GRAY),
                    ], spacing=8, vertical_alignment=ft.CrossAxisAlignment.CENTER),
                    ft.Checkbox(
                        label="Iniciar minimizada com o Windows (mantém os avisos ativos)",
                        value=state["start_with_windows"],
                        on_change=toggle_startup,
                    ),
                    ft.Text("Ao fechar no X, a aplicação continua minimizada na barra de tarefas. Clica no ícone para a reabrir.",
                            size=11, color=GRAY),
                ], spacing=12),
                padding=12,
                border=ft.Border.all(1, LINE), border_radius=6,
            ),
            empty,
        ]
        if state["timezone_fallback"]:
            controls.insert(3, ft.Text(
                "Base de fusos ausente; a mostrar o fuso configurado no Windows. Instala tzdata para escolher outros países.",
                size=11, color=RED,
            ))
        if state["error"]:
            controls.insert(2, ft.Text(state["error"], color=RED, size=12))
        return ft.Row([main_column(controls)], alignment=ft.MainAxisAlignment.CENTER,
                      expand=True, vertical_alignment=ft.CrossAxisAlignment.START)

    def render():
        content = {
            "competition": competition_screen,
            "teams": teams_screen,
            "schedule": schedule_screen,
            "email": email_setup_screen,
        }[state["screen"]]()
        page.clean()
        page.add(ft.Column([
            header(),
            ft.Container(content=progress(), padding=ft.Padding(left=0, top=18, right=0, bottom=14)),
            body_content(content),
            ft.Container(content=status, padding=ft.Padding(left=28, top=8, right=28, bottom=12)),
        ], expand=True, spacing=0))
        page.update()

    def body_content(content):
        return ft.Container(content=content, expand=True, bgcolor=WHITE)

    def go_to(screen):
        state["screen"] = screen
        save_config()
        render()

    def choose_scope(mode):
        state["scope"] = mode
        state["screen"] = "teams"
        save_config()
        render()

    def persist():
        save_config()
        render()

    def toggle_team(team):
        if team in state["favorites"]:
            state["favorites"].remove(team)
        else:
            state["favorites"].add(team)
        save_config()
        render()

    def select_all(value):
        if value:
            state["favorites"].update(scope_teams())
        else:
            state["favorites"].difference_update(scope_teams())
        save_config()
        render()

    def change_country(e):
        state["country"] = e.control.value
        save_config()
        render()

    def toggle_email(e):
        state["email_enabled"] = bool(e.control.value)
        save_config()
        render()

    def disable_email():
        state["email_enabled"] = False
        save_config()
        render()

    def toggle_startup(e):
        enabled = bool(e.control.value)
        if sys.platform != "win32":
            status.value = "O arranque automático só está disponível no Windows."
            render()
            return
        try:
            import winreg

            run_key = r"Software\Microsoft\Windows\CurrentVersion\Run"
            value_name = "ValorantGameChangersWidget"
            with winreg.CreateKeyEx(winreg.HKEY_CURRENT_USER, run_key, 0, winreg.KEY_SET_VALUE) as key:
                if enabled:
                    if getattr(sys, "frozen", False):
                        command = f'"{Path(sys.executable).resolve()}" --background'
                    else:
                        pythonw = Path(sys.executable).with_name("pythonw.exe")
                        executable = pythonw if pythonw.exists() else Path(sys.executable)
                        command = f'"{executable}" "{Path(__file__).resolve()}" --background'
                    winreg.SetValueEx(key, value_name, 0, winreg.REG_SZ, command)
                else:
                    try:
                        winreg.DeleteValue(key, value_name)
                    except FileNotFoundError:
                        pass
            state["start_with_windows"] = enabled
            save_config()
            status.value = "Arranque com o Windows ativado." if enabled else "Arranque com o Windows desativado."
        except OSError as error:
            state["start_with_windows"] = not enabled
            status.value = f"Não foi possível alterar o arranque automático: {error}"
        render()

    def save_email_draft(value):
        state["email_draft"] = value or ""
        save_config()

    async def exit_app(e):
        page.window.prevent_close = False
        await page.window.close()

    def change_lead(e):
        try:
            state["minutes_before"] = int(e.control.value)
        except (TypeError, ValueError):
            state["minutes_before"] = 15
        save_config()
        render()

    async def refresh_data():
        state["loading"] = True
        state["error"] = ""
        status.value = "A atualizar horários…"
        render()
        try:
            matches_payload = await asyncio.to_thread(api_get, "/match", {"q": "upcoming"})
            state["matches"] = get_segments(matches_payload)
            state["loading"] = False
            status.value = f"Horários atualizados às {datetime.now().strftime('%H:%M')}."
            render()
            await check_email_alerts()
        except Exception as error:
            state["loading"] = False
            state["error"] = f"Não foi possível carregar os horários: {error}"
            status.value = "Falha na atualização dos horários."
            render()

    async def load_logos():
        try:
            payload = await asyncio.to_thread(api_get, "/rankings", {"region": "gc"})
            logos = {}
            for item in get_segments(payload):
                name = item.get("team") or item.get("name")
                logo = item.get("logo") or item.get("img")
                if isinstance(name, str) and logo:
                    logo_url = str(logo)
                    if logo_url.startswith("//"):
                        logo_url = "https:" + logo_url
                    logos[name.casefold()] = logo_url
            for team in ALL_TEAMS:
                state["logos"][team] = logos.get(team.casefold()) or next(
                    (url for name, url in logos.items() if name in team.casefold() or team.casefold() in name), None
                )
            if state["screen"] == "teams":
                render()
        except Exception:
            pass

    async def check_email_alerts():
        if not state["email_enabled"] or not state["recipient_email"] or not state["favorites"]:
            return
        now = datetime.now(timezone.utc)
        for match in state["matches"]:
            scope = match_scope(match)
            if scope is None:
                continue
            followed = selected_match_team(match, scope)
            start = match_start(match)
            if not followed or not start:
                continue
            seconds = (start.astimezone(timezone.utc) - now).total_seconds()
            key = str(match.get("match_id") or f"{start.isoformat()}-{match.get('team1')}-{match.get('team2')}")
            if 0 < seconds <= state["minutes_before"] * 60 and key not in state["sent"] and key not in state["pending"]:
                state["pending"].add(key)
                body_text = (
                    f"{match.get('team1')} vs {match.get('team2')} começa em cerca de "
                    f"{max(1, round(seconds / 60))} minutos.\n"
                    f"Equipa acompanhada: {followed}.\n"
                    f"Torneio: {match.get('match_event', 'Game Changers')}"
                )
                try:
                    await asyncio.to_thread(send_email, "Jogo de VALORANT a começar", body_text, state["recipient_email"])
                    state["sent"].add(key)
                    write_json(SENT_FILE, sorted(state["sent"]))
                    status.value = f"Aviso enviado por email: {followed}."
                except Exception as error:
                    status.value = f"Email não enviado: {error}"
                finally:
                    state["pending"].discard(key)

    async def periodic_refresh():
        while True:
            await asyncio.sleep(120)
            await refresh_data()

    render()
    page.run_task(refresh_data)
    page.run_task(load_logos)
    page.run_task(periodic_refresh)


if __name__ == "__main__":
    ft.run(main)
