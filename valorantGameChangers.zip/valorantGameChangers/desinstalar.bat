@echo off
setlocal
title Desinstalar - VALORANT Game Changers

set "INSTALL_DIR=%LOCALAPPDATA%\Programs\ValorantGameChangers"
set "DATA_DIR=%APPDATA%\Valorant Game Changers"

echo A fechar a aplicacao e remover o arranque automatico...
taskkill /IM ValorantGameChangers.exe /F >nul 2>&1
reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" /v ValorantGameChangersWidget /f >nul 2>&1
powershell.exe -NoProfile -Command "$p=[Environment]::GetFolderPath('StartMenu') + '\Programs\VALORANT Game Changers.lnk'; Remove-Item -LiteralPath $p -Force -ErrorAction SilentlyContinue" >nul 2>&1

if exist "%INSTALL_DIR%" rmdir /S /Q "%INSTALL_DIR%"
echo Aplicacao removida. As tuas definicoes e o .env foram mantidos em:
echo %DATA_DIR%
echo.
choice /C SN /M "Queres apagar tambem os dados locais e as credenciais SMTP"
if errorlevel 2 goto :done
if exist "%DATA_DIR%" rmdir /S /Q "%DATA_DIR%"
echo Dados locais removidos.

:done
echo Desinstalacao concluida.
pause
