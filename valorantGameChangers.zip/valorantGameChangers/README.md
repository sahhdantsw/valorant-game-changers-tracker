# VALORANT Game Changers

Aplicacao desktop em Python/Flet para acompanhar horarios de equipas do VALORANT Game Changers e receber avisos por email.

## Instalar no Windows

1. Instala o [uv](https://docs.astral.sh/uv/getting-started/installation/).
2. Cria o ficheiro `.env` a partir de `.env.example` e preenche os dados SMTP.
3. Executa `instalar.bat`. O script prepara o ambiente, gera o executavel e instala a aplicacao.
4. Abre a aplicacao pelo Menu Iniciar. As definicoes e os dados SMTP ficam na pasta de dados do utilizador do Windows.

O primeiro empacotamento precisa de internet para descarregar as dependencias. O Python e o Flet nao precisam ficar abertos depois da instalacao.

## Executar em modo de desenvolvimento

```powershell
uv sync
uv run python app.py
```

## Email

`SMTP_USER` e `SMTP_PASSWORD` sao os dados da conta que envia os avisos. O destinatario e escolhido dentro da aplicacao. Mantem o `.env` privado; nunca publiques palavras-passe ou chaves SMTP.

Para Gmail, usa uma palavra-passe de aplicacao em vez da palavra-passe normal da conta.

## Desinstalar

Executa `desinstalar.bat`. Por defeito, as definicoes e o `.env` sao mantidos; o script permite apaga-los tambem.
